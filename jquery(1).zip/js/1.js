$(document).ready(function() {
	//TODO anything
	$("#clickme").click(function(){
		alert("hello jquery!");
	});
});
