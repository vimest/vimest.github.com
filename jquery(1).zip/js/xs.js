$(document).ready(function() {
	//TODO anything
});
